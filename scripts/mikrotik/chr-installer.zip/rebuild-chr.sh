#!/bin/bash
# ============================================================
#  Rebuild CHR tanpa download ulang
# ============================================================
set -e
CONFIG_FILE="/opt/chr-installer/config.conf"
WORK_DIR="/opt/chr-installer"
IMAGE_DIR="$WORK_DIR/chr-image"
SERVICE_PATH="/etc/systemd/system/chr.service"

source "$CONFIG_FILE"

systemctl stop chr 2>/dev/null || true
systemctl disable chr 2>/dev/null || true
pkill -f qemu-system-x86_64 || true
rm -f "$SERVICE_PATH"

qemu-system-x86_64   -name "$VM_NAME" -machine accel=kvm -cpu host -m "$RAM"   -drive file="$IMAGE_DIR/$IMAGE_FILE",if=virtio   -net nic -net user,hostfwd=tcp::$SSH_PORT-:22,hostfwd=tcp::$WINBOX_PORT-:8291,hostfwd=tcp::$API_PORT-:8728   -nographic -daemonize

systemctl daemon-reload
systemctl enable chr
systemctl restart chr
echo "✅ CHR berhasil direbuild!"
