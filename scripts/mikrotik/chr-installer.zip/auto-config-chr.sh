#!/bin/bash
# ============================================================
# Auto Konfigurasi CHR via RouterOS API
# ============================================================
set -e
apt install -y python3 python3-pip -qq
pip install routeros-api -q

python3 <<'PYCODE'
import routeros_api, time

CHR_HOST = "127.0.0.1"
CHR_PORT = 6928
CHR_USER = "admin"
CHR_PASS = ""

time.sleep(3)

try:
    conn = routeros_api.RouterOsApiPool(CHR_HOST, username=CHR_USER, password=CHR_PASS, port=CHR_PORT, plaintext_login=True)
    api = conn.get_api()
    print("✅ Terhubung ke CHR")

    api.get_resource('/ip/address').add(address='10.0.2.15/24', interface='ether1')
    api.get_resource('/ip/route').add(gateway='10.0.2.2')
    api.get_resource('/ip/dns').set(servers='8.8.8.8')

    for svc in ['telnet', 'ftp', 'www', 'www-ssl']:
        api.get_resource('/ip/service').set(id=svc, disabled='yes')

    api.get_resource('/ip/service').set(id='ssh', disabled='no')
    api.get_resource('/ip/service').set(id='api', disabled='no')
    api.get_resource('/ip/service').set(id='winbox', disabled='no')

    api.get_resource('/system/backup').save(name='auto-initial')
    print("✅ Konfigurasi CHR otomatis selesai!")

    conn.disconnect()
except Exception as e:
    print(f"❌ Gagal: {e}")
PYCODE
