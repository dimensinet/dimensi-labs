#!/bin/bash
# ============================================================
#  Auto Installer MikroTik CHR (QEMU / NAT)
#  Aman untuk Debian 12 + scure-debian12.sh
#  By Dimensi Labs
# ============================================================

set -e
CONFIG_FILE="/opt/chr-installer/config.conf"
WORK_DIR="/opt/chr-installer"
IMAGE_DIR="$WORK_DIR/chr-image"
LOG_DIR="$WORK_DIR/logs"
LOG_FILE="$LOG_DIR/install.log"

# --- [1] Root check ---
if [ "$EUID" -ne 0 ]; then
  echo "❌ Jalankan script ini sebagai root!"
  exit 1
fi

# --- [2] Buat folder ---
mkdir -p "$WORK_DIR" "$IMAGE_DIR" "$LOG_DIR"

# --- [3] Config default ---
if [ ! -f "$CONFIG_FILE" ]; then
cat <<EOF > "$CONFIG_FILE"
VM_NAME="chr-vm1"
RAM="256M"
DISK_SIZE="512M"
NET_MODE="nat"
SSH_PORT="6922"
WINBOX_PORT="6991"
API_PORT="6928"
IMAGE_URL="https://github.com/elseif/MikroTikPatch/releases/download/7.20.1/chr-7.20.1-legacy-bios.qcow2.zip"
IMAGE_FILE="chr-7.20.1-legacy-bios.qcow2"
EOF
fi

source "$CONFIG_FILE"

# --- [4] Install dependency ---
apt update -y >> "$LOG_FILE" 2>&1
apt install -y qemu-kvm libvirt-daemon-system libvirt-clients bridge-utils cpu-checker unzip wget curl >> "$LOG_FILE" 2>&1

# --- [5] Download CHR image ---
cd "$IMAGE_DIR"
if [ ! -f "$IMAGE_FILE" ]; then
  wget -q "$IMAGE_URL" -O chr.zip
  unzip -o chr.zip >> "$LOG_FILE" 2>&1
  rm -f chr.zip
fi

# --- [6] Resize disk ---
qemu-img resize "$IMAGE_FILE" "$DISK_SIZE" >> "$LOG_FILE" 2>&1

# --- [7] Jalankan CHR ---
qemu-system-x86_64   -name "$VM_NAME" -machine accel=kvm -cpu host -m "$RAM"   -drive file="$IMAGE_DIR/$IMAGE_FILE",if=virtio   -net nic -net user,hostfwd=tcp::$SSH_PORT-:22,hostfwd=tcp::$WINBOX_PORT-:8291,hostfwd=tcp::$API_PORT-:8728   -nographic -daemonize

# --- [8] Buat systemd service ---
SERVICE_PATH="/etc/systemd/system/chr.service"
cat <<EOF > "$SERVICE_PATH"
[Unit]
Description=MikroTik CHR QEMU VM
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/qemu-system-x86_64 -name $VM_NAME -machine accel=kvm -cpu host -m $RAM   -drive file=$IMAGE_DIR/$IMAGE_FILE,if=virtio   -net nic -net user,hostfwd=tcp::$SSH_PORT-:22,hostfwd=tcp::$WINBOX_PORT-:8291,hostfwd=tcp::$API_PORT-:8728   -nographic
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable chr
systemctl start chr

# --- [9] Info ---
clear
echo "✅ CHR berhasil diinstal!"
echo "SSH: ssh -p $SSH_PORT admin@<IP_PUBLIK>"
echo "Winbox: <IP_PUBLIK>:$WINBOX_PORT"
echo "API: <IP_PUBLIK>:$API_PORT"
